#ifndef FUNC_FORNECIDAS_H
#define FUNC_FORNECIDAS_H

#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void readline(char *string);
void binarioNaTela(char *nomeArquivoBinario);
void scan_quote_string(char *str);

#endif